const User = require("../models/User.js");

const updateUser = async (req,res)=>{
  try {
    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    return res.status(200).json(updatedUser);
  } catch (err) {
    return res.status(400).send({"message": "Unable to update user info"});
  }
}
const deleteUser = async (req,res)=>{
  try {
    await User.findByIdAndDelete(req.params.id);
    return res.status(200).json("User has been deleted.");
  } catch (err) {
    return res.status(400).send({"message": "Unable to delete user"});
  }
}
const getUser = async (req,res)=>{
  try {
    const user = await User.findById(req.params.id);
    return res.status(200).json(user);
  } catch (err) {
    return res.status(400).send({"message": "Unable to get user info"});
  }
}
const getUsers = async (req,res)=>{
  try {
    const users = await User.find();
    return res.status(200).json(users);
  } catch (err) {
    return res.status(400).send({"message": "Unable to get users"});
  }
}

module.exports = {
  updateUser,
  deleteUser,
  getUser,
  getUsers
}