const Record = require("../models/Record.js");
const url = require('url');

const register = async (req, res) => {
    try {
      const newRecord = new Record(req.body);
  
      await newRecord.save();
      return res.status(200).send("Record has been created.");
    } catch (err) {
      return res.status(400).send({"message": "Unable to register"});
    }
  };

const updateRecord = async (req,res)=>{
  try {
    const updatedRecord = await Record.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    return res.status(200).json(updatedRecord);
  } catch (err) {
    return res.status(400).send({"message": "Unable to update Record info"});
  }
}
const deleteRecord = async (req,res)=>{
  try {
    await Record.findByIdAndDelete(req.params.id);
    return res.status(200).json("Record has been deleted.");
  } catch (err) {
    return res.status(400).send({"message": "Unable to delete Record"});
  }
}
const getRecord = async (req,res)=>{
  try {
    const Record = await Record.findById(req.params.id);
    return res.status(200).json(Record);
  } catch (err) {
    return res.status(400).send({"message": "Unable to get Record info"});
  }
}

const getRecords = async (req,res)=>{
  try {
    const Records = await Record.find();
    return res.status(200).json(Records);
  } catch (err) {
    return res.status(400).send({"message": "Unable to get Records"});
  }
}

const getRecordsByTitle = async (req, res) => {
  try{
    // var searchQuery = {};
    // searchQuery.genre = req.query.genre;
    // searchQuery = {$regex: req.query.title, $options: 'i'};


     const records = await Record.find({'title': {'$regex': ".*"+req.query.q+".*" , '$options': 'i'}});
  // const records = await Record.find({"title": /.*dark.*/})
    return res.status(200).json(records);
  }
  catch(err){
    console.log(err);
  }
}

const getRecordsByGenre = async (req, res) => {
  try{
    const records = await Record.find({'genre': req.params.genre});
    return res.status(200).json(records);
  }
  catch(err){
    return res.status(400).json(err);
  }
}

module.exports = {
  register,
  updateRecord,
  deleteRecord,
  getRecord,
  getRecords,
  getRecordsByTitle,
  getRecordsByGenre
}