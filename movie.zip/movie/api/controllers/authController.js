const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Register

register = async(req, res) => {
  const useremail = await User.findOne({ email: req.body.email });
  const useruname = await User.findOne({ username: req.body.username });
  if(useremail){
      return res.status(401).json("Email already registered");
  }
  else if(useruname){
      return res.status(401).json("Username already registered");
  }
  else{
      try{
          const salt = await bcrypt.genSalt(10);
          const hashPass = await bcrypt.hash(req.body.password, salt)

          const newUser = new User(req.body);
          const user = await newUser.save();
          // Generate JWT Token
          const saved_user = await User.findOne({username: req.body.username});
          const token = jwt.sign({id: saved_user._id}, process.env.JWT_SECRET_KEY, { expiresIn: '5d'});
          return res.status(200).json({ user: user, token: token});
      }
      catch(err){
          return res.status(500).json(err);
      }
  }
}


//Login
login = async(req, res) => {
  try{
      const user = await User.findOne({ username: req.body.username });
      if(!user){
          return res.status(400).json("Wrong credentials");
      }
      else{
          const validate = await bcrypt.compare(req.body.password, user.password);
          if(!validate){
              return res.status(400).json("Wrong credentials");
          }
          else{
               // Generate JWT Token
               const token = jwt.sign({id: user._id}, process.env.JWT_SECRET_KEY, { expiresIn: '5d'});

              const { password, isAdmin, ...others } = user._doc;
              return res.status(200).json({ token: token, user });
          }
      }
  }
  catch(err){
      return res.status(500).json(err);
  }
}


module.exports = {
    register,
    login
}
