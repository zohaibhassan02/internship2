const router = require('express').Router();
const controller = require("../controllers/userController.js");
const jwtMiddleware = require("../middlewares/jwtMiddleware");

//UPDATE
router.put("/:id", jwtMiddleware.verifyUser, controller.updateUser);

//DELETE
router.delete("/:id", jwtMiddleware.verifyUser, controller.deleteUser);

//GET
router.get("/:id", jwtMiddleware.verifyUser, controller.getUser);

//GET ALL
router.get("/", jwtMiddleware.verifyUser, controller.getUsers);

module.exports = router;
