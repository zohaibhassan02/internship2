const router = require('express').Router();
const controller = require("../controllers/recordController.js");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

//REGISTER
router.post("/", jwtMiddleware.verifyAdmin, controller.register)

//UPDATE
router.put("/:id", jwtMiddleware.verifyAdmin, controller.updateRecord);

//DELETE
router.delete("/:id", jwtMiddleware.verifyAdmin, controller.deleteRecord);

//GET
router.get("/:id", controller.getRecord);

//GET ALL
router.get("/", controller.getRecords);

router.get("/search/find", controller.getRecordsByTitle);

router.get('/search/:genre', controller.getRecordsByGenre);

module.exports = router;
