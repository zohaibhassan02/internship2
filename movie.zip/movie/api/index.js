const express = require('express');
const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');

const authRoute = require('./routes/auth');
const userRoute = require('./routes/users');
const recordRoute = require('./routes/records');

// DB Config
dotenv.config();

// For body parsing of json 
app.use(express.json());
app.use(express.urlencoded({extended : true}));


mongoose.connect(process.env.MONGO_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(console.log("Database connected"))
  .catch((err) => console.log(err));


app.use('/api/auth', authRoute); 
app.use('/api/users', userRoute);
app.use('/api/records', recordRoute);

// app.use((err, req, res, next) => {
//   const errorStatus = err.status || 500;
//   const errorMessage = err.message || "Something went wrong!";
//   return res.status(errorStatus).json({
//     success: false,
//     status: errorStatus,
//     message: errorMessage,
//     stack: err.stack,
//   });
// });

app.listen(8000, ()=>{
  console.log('Server is up')
});