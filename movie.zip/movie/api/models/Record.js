const mongoose = require("mongoose");
const RecordSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    desc: {
      type: String,
    },
    releaseDate: {
      type: String,
    },
    img: {
      type: String,
    },
    rating: {
      type: Number,
      min: 0,
      max: 5,
    },
    type: {
      type: String,
      enum: ['movie', 'show'],
      default: "movie",
    },
    reviews:[{
        username: {
            type: String
        },
        comment: {
            type: String
        }
    }],
    genre: {
      type: String,
      required: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("records", RecordSchema);