import { Button } from "@chakra-ui/button"
import { Input, InputGroup, InputRightElement } from "@chakra-ui/input"
import { useState } from "react"
import { FaEye, FaEyeSlash } from 'react-icons/fa';

export default function PasswordInput(props) {
    const [show, setShow] = useState(false)
    const handleClick = () => setShow(!show);

    const [visibility, setVisibility] = useState(false);
    return (
        <InputGroup size="md">
            <Input
                {...props}
                type={show ? 'text' : 'password'}
                onMouseEnter={e => setVisibility(true)}
                onMouseLeave={e => setVisibility(false)}
            />
            {
                visibility ?
                (
                    <InputRightElement 
                        mr="4px"
                        onMouseEnter={e => setVisibility(true)}
                        onMouseLeave={e => setVisibility(false)}
                    >
                        <Button h="1.75rem" size="sm" bg={'transparent'} _hover={{ bg: 'transparent' }} _focus={{ outline: 'none', border: 'none' }} onClick={handleClick}>
                            {show ? (<FaEyeSlash />) : (<FaEye />)}
                        </Button>
                    </InputRightElement>
                ) : (<></>)
            }
        </InputGroup>
    )
}