import {
    Box,
    FormControl,
    FormLabel,
    Input,
    Checkbox,
    Stack,
    Link,
    Button,
    useColorModeValue,
    useToast
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {Link as ReactLink, useNavigate } from 'react-router-dom';
import { loginLocalStorage, loginCookies } from '../../reducers/usersReducer';
import { POST } from '../../utils/ApiRequestProvider';
import PasswordInput from '../Inputs/PasswordInput';

export default function SignInBox() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rememberMe, SetRememberMe] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const toast = useToast();
    const navigate = useNavigate();
    const user = useSelector(state => state.user.value);
    const dispatch = useDispatch();

    useEffect(() => {
        if(user?.verificationToken !== undefined) {
            dispatch(user.verificationToken);
            navigate('/');
        }
    }, [user, dispatch, toast, navigate]);


    async function handleSubmit(e) {
        e.preventDefault();

        setIsLoading(true);
        const response = await POST(
            '/api/auth/login', 
            {
                username: email,
                password
            }
        );

        setIsLoading(false);
        if(response.status === "200") {
            if(rememberMe) {
                dispatch(loginLocalStorage(response.data));
            }
            else {
                dispatch(loginCookies(response.data));
            }
            toast({
                title: "Logged In Successfully!",
                description: response.message,
                status: "success",
                duration: 3500,
                isClosable: true,
                position: "bottom-left"
            });
        }
        else {
            toast({
                title: "Whoops! Looks like there's an error!",
                description: response.message,
                status: "error",
                duration: 1500,
                isClosable: true,
                position: "bottom-left"
            });
        }
    }
    return (
        <Box
            rounded={'lg'}
            bg={useColorModeValue('white', 'gray.700')}
            boxShadow={'lg'}
            p={8}>
            <Stack spacing={4}>
                    <FormControl id="email">
                        <FormLabel>Email / Username</FormLabel>
                        <Input type="email" onChange={(e) => setEmail(e.target.value)} />
                    </FormControl>
                    <FormControl id="password">
                        <FormLabel>Password</FormLabel>
                        <PasswordInput onChange={(e) => setPassword(e.target.value)} />
                    </FormControl>
                    <Stack spacing={10}>
                        <Stack
                            direction={{ base: 'column', sm: 'row' }}
                            align={'start'}
                            justify={'space-between'}>
                            <Checkbox
                                value={rememberMe}
                                onChange={() => SetRememberMe(!rememberMe)}
                            >
                                Remember me
                            </Checkbox>
                            <Link color={'blue.400'} as={ReactLink} to="/forgotPassword">Forgot password?</Link>
                        </Stack>
                        <Button
                            bg={'blue.400'}
                            color={'white'}
                            _hover={{
                                bg: 'blue.500',
                            }}
                            isLoading={isLoading}
                            loadingText={'Signing In'}
                            spinnerPlacement={'end'}
                            onClick={handleSubmit}
                            >
                            Sign in
                        </Button>
                    </Stack>
            </Stack>
        </Box>
    )
}