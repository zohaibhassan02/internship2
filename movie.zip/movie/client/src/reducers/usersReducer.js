import { createSlice } from "@reduxjs/toolkit";
import Cookies from 'js-cookie';
export const userSlice = createSlice({
  name: "user",
  initialState: { },
  reducers: {
    loadState: (state, action) => {
      state.value = action.payload;
    },
    loginLocalStorage: (state, action) => {
      state.value = action.payload;
      localStorage.setItem("user", JSON.stringify(action.payload));
    },
    loginCookies: (state, action) => {
      state.value = action.payload;
      Cookies.set('user', JSON.stringify(action.payload));
    },
    changeProfilePicture: (state, action) => {
      state.value = {
        ...state.value,
        profile_picture: action.payload
      };
    },
    updateProfile: (state, action) => {
      state.value = {
        ...state.value,
        ...action.payload
      }
    },
    deleteProfilePicture: (state, action) => {
      state.value.profile_picture = null;
    },
    logout: (state) => {
      state.value = {};
      localStorage.removeItem("user");
      Cookies.remove('user');
    },
  },
});

export const {
  loadState,
  loginLocalStorage, 
  loginCookies, 
  logout,
  changeProfilePicture, 
  deleteProfilePicture, 
  updateProfile
} = userSlice.actions;

export default userSlice.reducer;