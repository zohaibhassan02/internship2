import React from 'react'

const Genre = () => {
  return (
    <div>Genre</div>
  )
}

export default Genre