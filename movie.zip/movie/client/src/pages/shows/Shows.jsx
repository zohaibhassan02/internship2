import React from 'react'

const Shows = () => {
  return (
    <div>Shows</div>
  )
}

export default Shows