// import React from 'react'
// import { useNavigate } from 'react-router-dom'

// const Favourites = () => {
//   const navigate = useNavigate();

//   console.log(localStorage.getItem('user'))

//   if(localStorage.getItem('user') == null){
//     navigate('/login');
//   }
//   return (
//     <div>Favourites</div>
//   )
// }

// export default Favourites

import React from 'react'

const Favourite = () => {
  return (
    <div>Favourite</div>
  )
}

export default Favourite