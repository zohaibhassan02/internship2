// import axios from "axios";
// import { useContext, useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import { AuthContext } from "../../context/AuthContext";
// import "./login.css";

// const Login = () => {
//   const [credentials, setCredentials] = useState({
//     username: undefined,
//     password: undefined,
//   });

//   const { loading, error, dispatch } = useContext(AuthContext);

//   const navigate = useNavigate()

//   useEffect(() => {
//     if (localStorage.getItem("authToken")) {
//       navigate('/');
//     }
//   }, [navigate]);


//   const handleChange = (e) => {
//     setCredentials((prev) => ({ ...prev, [e.target.id]: e.target.value }));
//   };

//   const config = {
//     header: {
//       "Content-Type": "application/json",
//     },
//   };

//   const handleClick = async (e) => {
//     e.preventDefault();
//     dispatch({ type: "LOGIN_START" });
//     try {
//       const res = await axios.post("/auth/login", credentials, config);
//       dispatch({ type: "LOGIN_SUCCESS", payload: res.data.user });
//       // console.log(res);
//       localStorage.setItem("authToken", res.data.token);

//       navigate(-1);
//     } catch (err) {
//       dispatch({ type: "LOGIN_FAILURE", payload: err.response.data });
//     }
//   };


//   return (
//     <div className="login">
//       <div className="lContainer">
//         <input
//           type="text"
//           placeholder="username"
//           id="username"
//           onChange={handleChange}
//           className="lInput"
//         />
//         <input
//           type="password"
//           placeholder="password"
//           id="password"
//           onChange={handleChange}
//           className="lInput"
//         />
//         <button disabled={loading} onClick={handleClick} className="lButton">
//           Login
//         </button>
//         {error && <span>{error.message}</span>}
//       </div>
//     </div>
//   );
// };

// export default Login;

import {
  Flex,
  Stack,
  Link,
  Heading,
  Text
} from '@chakra-ui/react';

import {Link as ReactLink } from 'react-router-dom';
import SignInBox from '../../components/Forms/SignInBox';

export default function Login() {
  return (
      <Flex
          minH={'100vh'}
          align={'center'}
          justify={'center'}
          // bg={useColorModeValue('gray.50', 'gray.800')}
          >
          <Stack spacing={8} mx={'auto'} maxW={'lg'} py={12} px={6}>
              <Stack align={'center'}>
                  <Heading fontSize={'4xl'}>Sign in to your account</Heading>
                  <Text fontSize={'lg'} color={'gray.600'}>
                      Don't have an account <Link color={'blue.400'} as={ReactLink} to="/signUp">Sign Up</Link>
                  </Text>
              </Stack>
              <SignInBox />
          </Stack>
      </Flex>
  );
}