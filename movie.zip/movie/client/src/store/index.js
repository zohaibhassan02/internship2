import { configureStore } from "@reduxjs/toolkit";
import reducer from '../reducers/usersReducer';

const store = configureStore({
    reducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            thunk: {},
            serializableCheck: false,
        }),
});

export default store;