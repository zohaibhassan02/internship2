import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/home/Home.jsx";
import Movies from "./pages/movies/Movies.jsx";
import Shows from "./pages/shows/Shows.jsx";
import Genres from "./pages/genres/Genres.jsx";
import Login from "./pages/login/Login.jsx";
import Favourites from "./pages/favourites/Favourite.jsx";
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loadState, logout } from './reducers/usersReducer';
import { GET } from './utils/ApiRequestProvider';
import { useToast } from '@chakra-ui/react';
import Cookies from 'js-cookie';


function App() {

  const toast = useToast();
  const dispatch = useDispatch();
  useEffect(async () => {
    if (localStorage.getItem("user") !== null) {
      const user = JSON.parse(localStorage.getItem("user"));
      // console.log(user);
      LoadUser(user);
    }
    else if (Cookies.get('user') !== undefined) {
      const user = JSON.parse(Cookies.get('user'));
      // console.log(user);
      LoadUser(user);
    }
  }, []);

  async function LoadUser(user) {
    const response = await GET(
      `/api/users/${user._id}`,
      {
        'Authorization': `Bearer ${user.verificationToken}`
      }
    );

    if (response.status == "200") {
      dispatch(loadState(response.data));
    }
    else {
      dispatch(logout());
      toast({
        title: "Whoops! Looks like there's an error!",
        description: response.message,
        status: "error",
        duration: 1500,
        isClosable: true,
        position: "bottom-left"
      });
    }
  }
  
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/movies" element={<Movies/>}/>
        <Route path="/shows" element={<Shows/>}/>
        <Route path="/genres" element={<Genres/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/favourites" element={<Favourites/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

