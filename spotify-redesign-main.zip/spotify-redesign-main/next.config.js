module.exports = {
  images: {
    domains: ['rb.gy'],
  },
}
