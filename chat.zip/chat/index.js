const cors = require('cors');
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const socketio = require('socket.io');
const io = socketio(server);
const formatMessage = require('./utils/messages');
const { userJoin, getCurrentUser, userLeave, getRoomUsers } = require('./utils/users');

app.use(cors());

const botname = 'MaceBot';

io.on('connection', (socket) => {
    
    socket.on('joinRoom', ({ username, room }) => {
        const user = userJoin(socket.id, username, room);

        socket.join(user.room);

        socket.emit('message', formatMessage(botname, 'Welcome to Macebook'));
        
        // Broadcast when a user connects
        socket.broadcast.to(user.room).emit('message', formatMessage(botname, `${user.username} has joined the chat`));

        // send usernames of ppl online in room
        io.to(user.room).emit('roomUsers', {
            room:user.room,
            users: getRoomUsers(user.room)
        });

    });
        
    socket.on('chat message', msg => {
            const user = getCurrentUser(socket.id);

            io.to(user.room).emit('chat message', formatMessage(user.username, msg));
    });

    socket.on('disconnect', () => {
        const user = userLeave(socket.id);

        if(user){
            console.log('user disconnected');
            io.to(user.room).emit('message', formatMessage(botname, `${user.username} has left the chat`));

             // send usernames of ppl online in room
            io.to(user.room).emit('roomUsers', {
                room:user.room,
                users: getRoomUsers(user.room)
            });
        }
    });

});

server.listen(3000, () => {
    console.log('listening on *:3000');
});