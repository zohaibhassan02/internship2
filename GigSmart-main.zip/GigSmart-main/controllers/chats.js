import jwt from 'jsonwebtoken';
import User from '../models/users.js';
import SimpleSchema from "simpl-schema";
import Chat from '../models/chats.js';
import Message from '../models/message.js';

const addChat = async (req, res) => {
    try {
        const chatSchema = new SimpleSchema({
            userid: String,
            connectedWith: String
        }).newContext(),
            body = req.body;

        if (!chatSchema.validate(body)) {
            return res.status(400).json({
                status: "400",
                message: "Some fields are missing, Please fill all the details first!",
                trace: body
            });
        }

        const user = await User.findById(body.userid).lean();
        if (!user) {
            return res.status(400).json({
                status: "400",
                message: "The User ID doesn't exists",
                trace: `USER ID: ${body.userid}`
            })
        }
        else {
            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }
            });
            if (invalidToken) return;
        }

        const connectedWith = await User.findById(body.connectedWith).lean();
        if (!connectedWith) return res.status(400).json({
            status: "400",
            message: "Sorry! The user doesn't exists!"
        });

        const chat = await Chat.findOne({$or: [{userid: body.userid, connectedWith: body.connectedWith}, {userid: body.connectedWith, connectedWith: body.userid}]}).lean();
        if(chat) return res.json({
            status: "200",
            message: "record already exists."
        });

        await new Chat(body).save().then(inserted => {
            return res.json({
                status: "200",
                message: "Successfully added chat",
                data: inserted
            });
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error.message
        });
    }
}

const getChat = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).lean();
        if(!user) return res.status(404).json({
            status: "404",
            message: "User against this id doesn't exists.",
            trace: `ID: ${req.params.id}`
        });
        
        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;
    
        let chats = await Chat.find({$or: [{userid: user._id}, {connectedWith: user._id}]}).lean();
        chats = await Promise.all(chats.map(async(chat) => {
            const user = await User.findById(chat.connectedWith.toString() === req.params.id ? chat.userid : chat.connectedWith, {password: 0, verificationToken: 0}).lean();
            const messages = await Message.find({chatid: chat._id}).lean();
            const lastMessage = messages[messages.length - 1]?.message;
            return {
                chatId: chat._id,
                ...user,
                lastMessage,
                chat_created: chat.created
            };
        }));
        return res.json({
            status: "200",
            message: `Successfully retrieved ${chats.length} for user: ${user.fullName ?? user.username}`,
            data: chats
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error.message
        });
    }
}

export default {
    addChat,
    getChat
}