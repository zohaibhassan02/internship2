import jwt from 'jsonwebtoken';
import User from '../models/users.js';
import SimpleSchema from "simpl-schema";
import Chat from '../models/chats.js';
import Message from '../models/message.js';
import { sendMessage } from '../utils/SocketHandler.js';
const addMessage = async (req, res) => {
    try {
        const messageSchema = new SimpleSchema({
            chatid: String,
            userid: String,
            type: String,
            message: String
        }).newContext(),
            body = req.body;

        if (!messageSchema.validate(body)) {
            return res.status(400).json({
                status: "400",
                message: "Some fields are missing, Please fill all the details first!",
                trace: body
            });
        }

        const user = await User.findById(body.userid).lean();
        if (!user) {
            return res.status(400).json({
                status: "400",
                message: "The User ID doesn't exists",
                trace: `USER ID: ${body.userid}`
            })
        }
        else {
            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }
            });
            if (invalidToken) return;
        }

        const chat = await Chat.findById(body.chatid).lean();
        if(!chat) return res.status(404).json({
            status: "404",
            message: "No chat found against this id."
        });

        await new Message(body).save().then(inserted => {
            const data = inserted;
            data.receiver = chat.userid.toString() === body.userid ? chat.connectedWith.toString() : chat.userid.toString();
            console.log(data);
            sendMessage(req, data);
            return res.json({
                status: "200",
                message: "Successfully added message",
                data: inserted
            });
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error.message
        });
    }
}

const getMessages = async (req, res) => {
    try {
        const user = await User.findById(req.params.userid).lean();
        if(!user) return res.status(404).json({
            status: "404",
            message: "User against this id doesn't exists.",
            trace: `ID: ${req.params.userid}`
        });
        
        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;
        
        const chatMessages = await Message.find({chatid: req.params.chatid}).lean();
        return res.json({
            status: "200",
            message: `Successfully retrieved ${chatMessages.length} for user: ${user.fullName ?? user.username}`,
            data: chatMessages
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error.message
        });
    }
}

export default {
    addMessage,
    getMessages
}