import jwt from 'jsonwebtoken';
import helper from '../utils/helpers.js';
import Gigs from '../models/Gigs.js';
import User from '../models/users.js';
import SimpleSchema from "simpl-schema";
 
const addGig = async (req, res) => {
    try {
        const gigSchema = new SimpleSchema({
            title: String,
            introduction: String,
            details: String,
            pricing_detail: String,
            price: String,
            userid: String,
            location: String
        }).newContext(),
            body = req.body,
            cover_image = req.files.cover_image;

        if (!gigSchema.validate(body) || cover_image === undefined || cover_image === null) {
            return res.status(400).json({
                status: "400",
                message: "Some fields are missing, Please fill all the details first!",
                trace: body
            })
        }

        const user = await User.findById(body.userid).lean();

        if (!user) {
            return res.status(400).json({
                status: "400",
                message: "The User ID doesn't exists",
                trace: `USER ID: ${body.userid}`
            })
        }
        else {
            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }
            });
            if (invalidToken) return;
        }

        let fileName = `public/gigs/${Date.now()}-${cover_image.name.replace(/ /g, '-').toLowerCase()}`;
        cover_image.mv(fileName, async (err) => {
            if (err) return res.status(400).json({ status: "400", message: "An unexpected error occured while proceeding your request.", trace: err });
            body.cover_image = fileName.replace("public", "");

            await new Gigs(body).save().then(inserted => {
                return res.json({
                    status: "200",
                    message: "Your gig has been posted successfully!",
                    data: inserted
                })
            }).catch(err => {
                return res.status(500).json({
                    status: "500",
                    message: "An unexpected error occured while proceeding your request.",
                    trace: err.message
                })
            })
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error.message
        })
    }
}

const getGig = async (req, res) => {
    try {
        const id = req.params.id;

        const gig = await Gigs.findById(id).lean();

        if (gig) {
            const user = await User.findById(gig.userid).lean();
            delete user.password;
            delete user.verificationToken;
            delete gig.userid;

            gig.user = user;
            return res.json({
                status: 200,
                message: `Successfully retrieved Gig: ${gig.title} from ID: ${id}`,
                data: gig
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Gigs Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error
        })
    }
}

const updateGig = async (req, res) => {
    try {
        let body = req.body,
            cover_image = req.files.cover_image;

        const id = req.params.id,
            gig = await Gigs.findById(id).lean();

        if (gig) {
            const user = await User.findById(gig.userid).lean();

            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }
            });
            if (invalidToken) return;

            if (body.userid !== undefined) {
                return res.status(400).json({
                    status: "400",
                    message: "You can't change user id of a Gig.",
                    trace: `UserID: ${body.userid}`
                });
            }

            if (cover_image !== undefined) {
                let fileName = `public/gigs/${Date.now()}-${cover_image.name.replace(/ /g, '-').toLowerCase()}`;
                cover_image.mv(fileName, async (err) => {
                    if (err) return res.status(400).json({ status: "400", message: "An unexpected error occured while proceeding your request.", trace: err });
                });
                body.cover_image = fileName.replace("public", "");
            }

            Gigs.updateOne({ _id: id }, { $set: body }).then(async () => {
                delete user.password;
                delete user.verificationToken;

                const updatedGig = await Gigs.findById(req.params.id).lean();
                updatedGig.user = user;

                return res.json({
                    status: "200",
                    message: "Gig Updated!",
                    data: updatedGig
                });
            }).catch(err => {
                return res.status(500).json({
                    status: "500",
                    message: "An unexpected error occurred while proceeding your request.",
                    trace: err.message
                })
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Gigs Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err
        });
    }
};

const GigFeed = async (req, res) => {
    try {
        Gigs.find({title:  {$regex: (req.query.search != undefined) ? helper.regexSearch(req.query.search) : '' }}).lean().then(async (records) => {
            const results = {};
            const page = parseInt(req.query.page);
            const limit = req.query.limit == 0 ? 5 : parseInt(req.query.limit);
            const startIndex = (page - 1) * limit;
            const endIndex = page * limit;
            if (endIndex < records.length) {
                results.next = {
                    page: page + 1,
                    limit: limit
                }
            }
            if (startIndex > 0) {
                results.previous = {
                    page: page - 1,
                    limit: limit
                }
            }
            results.totalPages = {
                page: Math.ceil(records.length / limit),
                limit: limit,
                totalRecords: records.length
            };

            results.result = records.slice(startIndex, endIndex);
            results.result = await Promise.all(results.result.map(async (result, i) => {
                const user = await User.findById(result.userid).lean();
                delete user.verificationToken;
                delete user.password;
                delete result.userid;

                result.user = user;
                return result;
            }));
            
            return res.json({
                status: "200",
                message: "Gigs Feed Retrieved Successfully!",
                data: results
            });
        }).catch(err => {
            if (err) {
                return res.status(500).json({
                    status: "500",
                    message: err.message,
                    trace: err
                });
            }
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error
        })
    }
}

const usersGigs = async (req, res) => {
    try {
        const userid = req.params.userid;
        Gigs.find({userid}).lean().then(async (records) => {
            const results = {};
            const page = parseInt(req.query.page);
            const limit = req.query.limit == 0 ? 5 : parseInt(req.query.limit);
            const startIndex = (page - 1) * limit;
            const endIndex = page * limit;
            if (endIndex < records.length) {
                results.next = {
                    page: page + 1,
                    limit: limit
                }
            }
            if (startIndex > 0) {
                results.previous = {
                    page: page - 1,
                    limit: limit
                }
            }
            results.totalPages = {
                page: Math.ceil(records.length / limit),
                limit: limit,
                totalRecords: records.length
            };

            results.result = records.slice(startIndex, endIndex);
            results.result = await Promise.all(results.result.map(async (result, i) => {
                const user = await User.findById(result.userid).lean();
                delete user.verificationToken;
                delete user.password;
                delete result.userid;

                result.user = user;
                return result;
            }));
            return res.json({
                status: "200",
                message: "Gigs Feed Retrieved Successfully!",
                data: results
            })
        }).catch(err => {
            if (err) {
                return res.status(500).json({
                    status: "500",
                    message: err.message,
                    trace: err
                });
            }
        });
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: error
        })
    }
}

const deleteGig = async (req, res) => {
    try {
        const id = req.params.id;

        const gig = await Gigs.findById(id).lean();

        if (gig) {
            const user = await User.findById(gig.userid).lean();

            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }
            });
            if (invalidToken) return;

            Gigs.findByIdAndDelete(id, (err, docs) => {
                if (err) res.status(500).json({ status: "500", message: "An unexpected error occured while proceeding your request.", trace: err });
                res.json({
                    status: "200",
                    message: "Your gig has been removed successfully.",
                    data: docs
                });
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Gigs Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: `An unexpected error occured while proceeding your request.`,
            trace: err
        })
    }
};

const appointGig = async(req, res) => {
    try {
        const {gigId, buyerId} = req.body;
        if(!gigId || !buyerId) {
            return res.status(400).json({
                status: "400",
                message: "Please enter Gig ID and User ID to proceed further.",
                trace: `{GIG ID: ${gig}, USER ID: ${user}}`
            });
        }
        
        const user = await User.findById(buyerId).lean(),
        gig = await Gigs.findById(gigId).lean();
        
        if(gig) {
            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }

                if(user.type !== "BUYER") {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "A seller can not appoint a gig. Please create a buyer account and proceed further.",
                        trace: `{TYPE: ${user.type}}`
                    })
                }
            });
            if (invalidToken) return;

            const appointmentExists = await Gigs.findOne({_id: gigId, "appointments_request.buyerId": buyerId});
            let updateQuery = {$push: {appointments_request: {buyerId: buyerId}}};
            if(appointmentExists) updateQuery = {$pull: {appointments_request: {buyerId: buyerId}}};
            
            await Gigs.findOneAndUpdate({_id: gigId}, updateQuery);
            const updatedGig = await Gigs.findOne({_id: gigId}).lean();
            
            return res.json({
                status: "200",
                message: !appointmentExists ? "Gig Appointment Sent for Approval" : "Appointment Cancelled!",
                data: updatedGig.appointments_request
            })
        }
        else {
            return res.status(404).json({
                status: "400",
                message: "No Gigs Found! Please re-try with a different Id.",
                trace: `{GIG ID: ${gigId}}`
            });
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err
        })
    }
};

export default {
    addGig,
    getGig,
    GigFeed,
    deleteGig,
    updateGig,
    appointGig,
    usersGigs
}