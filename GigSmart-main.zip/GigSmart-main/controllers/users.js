import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import helper from '../utils/helpers.js';
import User from '../models/users.js';
import SimpleSchema from "simpl-schema";
import Gigs from '../models/Gigs.js';

const register = async (req, res) => {
    try {
        let { username, email, password, type } = req.body;

        const userSchema = new SimpleSchema({
            username: String,
            email: String,
            password: String,
            type: String
        }).newContext();

        if (!userSchema.validate({ username, email, password, type })) {
            res.status(400).json({
                status: "400",
                message: "Username, Email or Password is missing!",
                trace: `{username: "${username}", email: "${email}", password: "${password}", type: "${type}"}`
            })
        }

        const userExist = await User.findOne({ $or: [{ email }, { username }] });
        if (userExist) {
            return res.status(409).json({
                status: "409",
                message: "A user with this username or email already exists.",
                trace: { username, email }
            });
        }

        if (!helper.ValidateEmail(email)) {
            return res.status(400).json({
                status: "400",
                message: "Please enter a valid email address.",
                trace: `Email Address: ${email} is not valid`
            });
        }

        password = await bcrypt.hash(password, 10);
        type = type.toString().toLowerCase().charAt(0) === "b" ? "BUYER" : "SELLER";

        await new User({ username, email, password, type }).save().then(inserted => {
            return res.json({
                status: "200",
                message: "User Added Successfully",
                data: inserted
            })
        }).catch(err => {
            return res.status(500).json({
                status: "500",
                message: "An unexpected error occurred while proceeding your request.",
                trace: { err, requestBody: { username, email, password } }
            })
        });
    } catch (error) {
        res.status(500).json({
            status: "500",
            message: "An unexpected error occurred while proceeding your request.",
            trace: error
        })
    }
}

const login = async (req, res) => {
    try {
        let { username, password } = req.body;
        const loginSchema = new SimpleSchema({
            username: String,
            password: String
        }).newContext();

        if (!loginSchema.validate({ username, password })) {
            return res.status(400).json({
                status: "400",
                message: "Username or Password is missing.",
                trace: `{username: ${username}, password: ${password}}`
            });
        }
        let user = {};
        if (!helper.ValidateEmail(username)) {
            user = await User.findOne({ username }).lean();
        }
        else {
            user = await User.findOne({ email: username }).lean();
        }

        if (!user) {
            return res.status(404).json({
                status: "404",
                message: `User: ${username} doesn't exists.`,
                trace: `{username: ${username}, password: ${password}}`
            });
        }

        const isPassword = await bcrypt.compare(password, user.password);
        if (isPassword) {
            const token = jwt.sign({ id: user._id, username: user.userName }, process.env.JWT_SECRET);
            delete user.password;
            delete user.verificationToken;
            user.verificationToken = token;

            User.updateOne({ _id: user._id }, { $set: { verificationToken: token } }).then(response => {
                return res.json({
                    status: "200",
                    message: `Login Successful! Logged in as ${username}`,
                    data: user
                })
            }).catch(err => {
                return res.status(500).json({
                    status: "500",
                    message: "An unexpected error occurred while proceeding your request.",
                    trace: err
                })
            });
        }
        else {
            return res.status(400).json({
                status: "400",
                message: "Incorrect Password.",
                trace: `Password: ${password} is incorrect`
            });
        }
    } catch (error) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occurred while proceeding your request.",
            trace: error
        })
    }
}

const profilePicture = async (req, res) => {
    try {
        const id = req.params.id;
        let profilePicture = req.files?.profilePicture;

        if (!profilePicture) return res.status(400).json({
            status: "400",
            message: "Please add profile picture to continue.",
            trace: body
        });

        const user = await User.findById(id).lean();
        if (!user) return res.status(404).json({
            status: "400",
            message: "Can't find user! Please re-try.",
            trace: `UserID: ${id}`
        });

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;

        let fileName = `public/profiles/${Date.now()}-${profilePicture.name.replace(/ /g, '-').toLowerCase()}`;
        profilePicture.mv(fileName, async (err) => {
            if (err) return res.status(400).json({ status: "400", message: "An unexpected error occured while proceeding your request.", trace: err });
            profilePicture = fileName.replace("public", "");

            try {
                await User.updateOne({ _id: id }, { $set: { profile_picture: profilePicture } });
                const userUpdated = await User.findById(id);
                return res.json({
                    status: "200",
                    message: "Profile Picture Updated!",
                    data: userUpdated.profile_picture
                });
            } catch (err) {
                return res.status(500).json({
                    status: "500",
                    message: "An unexpected error occurred while proceeding your request.",
                    trace: err
                })
            }
        });
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
};

const deleteProfilePicture = async (req, res) => {
    try {
        const id = req.params.id;

        const user = await User.findById(id).lean();
        if (!user) return res.status(404).json({
            status: "400",
            message: "Can't find user! Please re-try.",
            trace: `UserID: ${id}`
        });

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;

        try {
            await User.updateOne({ _id: id }, { $set: { profile_picture: null } });
            return res.json({
                status: "200",
                message: "Profile Picture Removed!"
            });
        } catch (err) {
            return res.status(500).json({
                status: "500",
                message: "An unexpected error occurred while proceeding your request.",
                trace: err
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
};

const updateUser = async (req, res) => {
    try {
        const id = req.params.id;
        let body = req.body;

        const user = await User.findById(id).lean();
        if (!user) return res.status(404).json({
            status: "404",
            message: `No Users Found! Please try again with a different id.`,
            trace: `ID: ${id}`
        });

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;

        if (body.password !== undefined) {
            body.password = await bcrypt.hash(body.password, 10);
        }

        if (body.verificationToken !== undefined) {
            return res.status(400).json({
                status: "400",
                message: "Sorry! You can't update verification token.",
                trace: body
            })
        }

        User.updateOne({ _id: req.params.id }, { $set: body }).then(response => {
            delete user.password;
            delete user.verificationToken;
            return res.json({
                status: "200",
                message: "Profile Updated!",
                data: body
            });
        }).catch(err => {
            return res.status(500).json({
                status: "500",
                message: "An unexpected error occurred while proceeding your request.",
                trace: err
            })
        });
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
};

const deleteUser = async (req, res) => {
    try {
        const id = req.params.id;

        const user = await User.findById(id).lean();

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(400).json({
                    status: "400",
                    message: "Invalid JWT Token! Please Login again to continue.",
                    trace: req.token
                })
            }
        });
        if (invalidToken) return;

        if (user) {
            delete user.password;
            delete user.verificationToken;
            User.findByIdAndDelete(id, (err, docs) => {
                if (err) res.status(500).json({ status: "500", message: "An unexpected error occured while proceeding your request.", trace: err });
                res.json({
                    status: "200",
                    message: "Your account has been removed successfully.",
                    data: docs
                });
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Users Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
};

const getUser = async (req, res) => {
    try {
        const id = req.params.id;
        const user = await User.findById(id).lean();

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (user.verificationToken !== req.token) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "Your sign-in token has been expired! Please sign-in again to continue." });
            }
        });
        if (invalidToken) return;

        if (user) {
            delete user.password;
            return res.json({
                status: "200",
                message: `Successfully retrieved User: ${user.username} from ID: ${id}`,
                data: user
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Users Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        });
    }
}

const getUserProfile = async (req, res) => {
    try {
        const id = req.params.id;
        const user = await User.findById(id, { password: 0, verificationToken: 0 }).lean();

        if (user) {
            return res.json({
                status: "200",
                message: `Successfully retrieved User: ${user.username} from ID: ${id}`,
                data: user
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: `No Users Found! Please try again with a different id.`,
                trace: `ID: ${id}`
            })
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        });
    }
}

const appointmentRequests = async (req, res) => {
    try {
        const id = req.params.id,
            user = await User.findById(id);
        if (!user) return res.status(400).json({ status: "400", message: "Invalid user! This user doesn't exist.", trace: `{${id}}` });

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(403).json({
                    status: "403",
                    message: "Invalid Verification Token! Please login again to continue.",
                    trace: req.token
                });
            }
        });
        if (invalidToken) return;

        let requests = undefined;
        if (user.type == 'BUYER') {
            requests = await Gigs.find(
                {
                    "appointments_request.buyerId": id
                }
            ).select("appointments_request cover_image userid title introduction location").lean();

            requests = await Promise.all(requests.map(async (request) => {
                let appointmentDetails = request.appointments_request.filter(ar => ar.buyerId == id)[0];
                delete request.appointments_request;
                const user = await User.findById(request.userid, { _id: 0 }).select("fullName email username profile_picture city state country").lean();
                return {
                    ...request,
                    ...user,
                    requestDate: appointmentDetails?.created
                };
            }));
        }
        else {
            requests = await Gigs.find(
                {
                    userid: '619d74d587c07470260f95ed',
                    appointments_request: { $exists: true, $type: 'array', $ne: [] }
                }
            ).select("appointments_request cover_image title introduction location").lean();
            requests = await Promise.all(requests.map(async (request) => {
                request.appointments_request = await Promise.all(request.appointments_request.map(async (appointment) => {
                    const user = await User.findById(appointment.buyerId, { _id: 0 }).select("fullName email username profile_picture city state country").lean();
                    return {
                        ...appointment,
                        ...user
                    }
                }));
                return request;
            }));
        }

        return res.json({
            status: "200",
            message: `Retrieved ${requests.length} Requests for User: ${user.username}`,
            data: requests
        });
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
}

const confirmAppointment = async (req, res) => {
    try {
        const gigId = req.body.gigId,
            appointmentId = req.body.appointmentId;
        if (!gigId || !appointmentId) return res.status(400).json({ status: "400", message: "Please enter Gig ID and Appointment Id.", trace: { gigId, appointmentId } });

        const gig = await Gigs.findOne(
            {
                _id: gigId,
                "appointments_request._id": appointmentId
            }, { _id: 0 }
        ).select("appointments_request userid").lean(),
            user = await User.findById(gig.userid).lean();

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(403).json({
                    status: "403",
                    message: "Invalid Verification Token! Please login again to continue.",
                    trace: req.token
                });
            }
        });
        if (invalidToken) return;

        const buyerId = gig.appointments_request.map(appointment => {
            if (appointment._id == appointmentId) {
                return appointment.buyerId;
            }
        })[0];

        await Gigs.updateOne({ _id: gigId }, { $pull: { appointments_request: { _id: appointmentId } } });
        await Gigs.updateOne({ _id: gigId }, { $push: { appointments: { buyerId: buyerId } } });

        const updatedGig = await Gigs.findById(gigId).select("appointments");
        return res.json({
            status: "200",
            message: "Appointment Confirmed!",
            data: updatedGig
        });
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        });
    }
}

const completeAppointment = async (req, res) => {
    try {
        const { gigId, buyerId, reviewTitle, reviewText } = req.body;
        if (!gigId || !buyerId || !reviewTitle || !reviewText) {
            return res.status(400).json({
                status: "400",
                message: "Please enter Gig ID and User ID to proceed further.",
                trace: `{GIG ID: ${gig}, USER ID: ${user}}`
            });
        }

        const user = await User.findById(buyerId).lean(),
            gig = await Gigs.findById(gigId).lean();

        if (gig) {
            let invalidToken = false;
            jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
                if (err) {
                    invalidToken = true;
                    return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
                }

                if (req.token !== user.verificationToken) {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "Invalid JWT Token! Please Login again to continue.",
                        trace: req.token
                    })
                }

                if (user.type !== "BUYER") {
                    invalidToken = true;
                    return res.status(400).json({
                        status: "400",
                        message: "A seller can not appoint a gig. Please create a buyer account and proceed further.",
                        trace: `{TYPE: ${user.type}}`
                    })
                }
            });
            if (invalidToken) return;

            await Gigs.findOneAndUpdate({ _id: gigId }, { $push: { completed_appointments: { buyerId: buyerId } } });
            await Gigs.findOneAndUpdate({ _id: gigId }, { $pull: { appointments: { buyerId: buyerId } } });
            await Gigs.findOneAndUpdate({ _id: gigId }, { $push: { reviews: { reviewTitle, reviewText } } });
            const updatedGig = await Gigs.findOne({ _id: gigId }).lean();

            return res.json({
                status: "200",
                message: "Thank you for your feedback! Your response has been recorded.",
                data: updatedGig.appointments
            });
        }
        else {
            return res.status(404).json({
                status: "400",
                message: "No Gigs Found! Please re-try with a different Id.",
                trace: `{GIG ID: ${gigId}}`
            });
        }
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err
        })
    }
}

const appointmentsConfirmed = async (req, res) => {
    try {
        const id = req.params.id,
            user = await User.findById(id);
        if (!user) return res.status(400).json({ status: "400", message: "Invalid user! This user doesn't exist.", trace: `{${id}}` });

        let invalidToken = false;
        jwt.verify(req.token, process.env.JWT_SECRET, (err, authData) => {
            if (err) {
                invalidToken = true;
                return res.status(401).json({ status: "401", message: "JWT not verified", trace: err });
            }

            if (req.token !== user.verificationToken) {
                invalidToken = true;
                return res.status(403).json({
                    status: "403",
                    message: "Invalid Verification Token! Please login again to continue.",
                    trace: req.token
                });
            }
        });
        if (invalidToken) return;

        let requests = undefined;
        if (user.type == 'BUYER') {
            requests = await Gigs.find(
                {
                    "appointments.buyerId": id
                }
            ).select("appointments cover_image userid title introduction location").lean();

            requests = await Promise.all(requests.map(async (request) => {
                // request.appointments = request.appointments.filter(ar => ar.buyerId == id);
                delete request.appointments;
                const user = await User.findById(request.userid, { _id: 0 }).select("firstname lastname email username profile_picture city state country").lean();
                return {
                    ...request,
                    ...user
                };
            }));
        }
        else {
            requests = await Gigs.find(
                {
                    userid: id,
                    "appointments": { $exists: true, $type: 'array', $ne: [] }
                }
            ).select("appointments cover_image title introduction location").lean();
            requests = await Promise.all(requests.map(async (request) => {
                request.appointments = await Promise.all(request.appointments.map(async (appointment) => {
                    const user = await User.findById(appointment.buyerId, { _id: 0 }).select("firstname lastname email username profile_picture city state country").lean();
                    return {
                        ...appointment,
                        ...user
                    }
                }));
                return request;
            }));
        }

        return res.json({
            status: "200",
            message: `Retrieved ${requests.length} Approved of User: ${user.username}`,
            data: requests
        });
    } catch (err) {
        return res.status(500).json({
            status: "500",
            message: "An unexpected error occured while proceeding your request.",
            trace: err.message
        })
    }
}

export default {
    register,
    getUser,
    getUserProfile,
    login,
    updateUser,
    deleteUser,
    profilePicture,
    deleteProfilePicture,
    appointmentRequests,
    confirmAppointment,
    appointmentsConfirmed,
    completeAppointment
};