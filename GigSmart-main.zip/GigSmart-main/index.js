import express from "express";
import dotenv from 'dotenv';
import usersRoutes from "./routes/users.js";
import gigsRoutes from "./routes/Gigs.js";
import chatRoutes from "./routes/chats.js";
import messageRoutes from "./routes/message.js";
import mongoose from "mongoose";
import upload from 'express-fileupload';
import path from 'node:path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { Server, Socket } from "socket.io";
import jwt from 'jsonwebtoken';
import cors from 'cors';
import Users from "./models/users.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();
var PORT = process.env.PORT,
    DB_URL = process.env.DB_URL

mongoose.connect(DB_URL, (e) => console.log(e == null ? "Database Connected!" : e));

const app = express();
app.use(express.json());
app.use(upload());
app.use(express.static('public'));
app.use(cors());

app.use("/api/users", usersRoutes);
app.use("/api/gigs", gigsRoutes);
app.use("/api/chats", chatRoutes);
app.use("/api/messages", messageRoutes);

// For GigSmart UI
app.use(express.static(path.join(__dirname, 'web')));
app.get('/*', function (req, res) {
    res.sendFile(path.join(__dirname, 'web', 'index.html'));
});

const expressServer = app.listen(PORT, () => {
    console.log(`Server running on port: http://localhost:${PORT}`);
});

const io = new Server(expressServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

app.set('socket', io);
console.log('Socket.io listening for connections');

// Authenticate before establishing a socket connection
io.use(async(socket, next) => {
    const token = socket.handshake.query.token;
    if (token) {
        try {
            const isTokenValid = jwt.decode(token, process.env.JWT_SECRET);
            if (!isTokenValid) {
                socket.emit('conflict', "Not authorized");
                return next(new Error('Not authorized.'));
            }
            const user = await Users.findOne({verificationToken: token});
            if(!user) {
                socket.emit('conflict', "Invalid Token! Please login again to continue.");
                return next(new Error('Invalid Token! Please login again to continue.'));
            }
            socket.user = user;
            return next();
        } catch (err) {
            socket.emit('conflict', err.message);
            next(err);
        }
    } else {
        socket.emit('conflict', "Not authorized");
        return next(new Error('Not authorized.'));
    }
    return next();
}).on('connection', (socket) => {
    socket.join(socket.user._id.toString());
    socket.broadcast.emit(socket.user._id.toString(), "Online 🟢");
    
    socket.on('disconnect', req => {
        socket.broadcast.emit(socket.user._id.toString(), "Offline 🔴");
    });
    
    socket.on('typing', (req) => {
        socket.to(req.receiver).emit('typing', req);
    });

    socket.on('test', req => {
        console.log(req);
        socket.emit('test', req);
    });

    socket.on('status', req => {
        const onlineUsers = Array.from(io.sockets.adapter.rooms.keys());
        let status = onlineUsers.find(user => user === req) !== undefined ? "Online 🟢" : "Offline 🔴";
        socket.emit(req, status);
    });
});