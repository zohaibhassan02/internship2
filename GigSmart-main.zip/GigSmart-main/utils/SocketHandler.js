export function sendNotification(req, notification) {
    const io = req.app.get('socket');
    io.sockets.to(notification.receiver).emit('notification', notification);
};

export function sendMessage(req, message) {
    const io = req.app.get('socket');
    io.sockets.in(message.receiver).emit('message', message);
};