import helper from '../utils/helpers.js'; 
import express from 'express';
import chatController from '../controllers/chats.js';
const router = express.Router();

router.post('/', helper.verifyToken, chatController.addChat);
router.get('/:id', helper.verifyToken, chatController.getChat);

export default router;