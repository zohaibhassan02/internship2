import helper from '../utils/helpers.js'; 
import express from 'express';
import messageController from '../controllers/message.js';
const router = express.Router();

router.post('/', helper.verifyToken, messageController.addMessage);
router.get('/:userid/:chatid', helper.verifyToken, messageController.getMessages);

export default router;