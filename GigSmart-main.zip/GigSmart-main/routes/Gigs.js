import helper from '../utils/helpers.js'; 
import express from 'express';
import gigController from '../controllers/Gigs.js';
const router = express.Router();

router.get('/feed', gigController.GigFeed);
router.post('/appoint', helper.verifyToken, gigController.appointGig);
router.get('/user/:userid', gigController.usersGigs);

router.get('/:id', gigController.getGig);
router.post('/', helper.verifyToken, gigController.addGig);
router.put('/:id', helper.verifyToken, gigController.updateGig);
router.delete('/:id', helper.verifyToken, gigController.deleteGig);

export default router;