import helper from '../utils/helpers.js'; 
import express from 'express';
import userController from '../controllers/users.js';
const router = express.Router();

router.post('/login', userController.login);
router.get('/appointmentRequests/:id', helper.verifyToken, userController.appointmentRequests);
router.get('/appointmentsConfirmed/:id', helper.verifyToken, userController.appointmentsConfirmed);
router.post('/confirmAppointment', helper.verifyToken, userController.confirmAppointment);
router.post('/completeAppointment', helper.verifyToken, userController.completeAppointment);
router.post('/profilePicture/:id', helper.verifyToken, userController.profilePicture);
router.delete('/profilePicture/:id', helper.verifyToken, userController.deleteProfilePicture);

router.get('/profile/:id', userController.getUserProfile);
router.get('/:id', helper.verifyToken, userController.getUser);
router.post('/', userController.register);
router.put('/:id', helper.verifyToken, userController.updateUser);
router.delete('/:id', helper.verifyToken, userController.deleteUser);
export default router;