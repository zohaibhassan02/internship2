Run this command to install essential libraries for the application to run:
```
npm install
```

Run this command afterwards to run application on the machine.
```
npm start
```

Information
1. The backend flow is simple. index.js files runs and initializes the server. When a request hits the server, It will be passed on to it's specific controller automatically by the express server. And if it doesn't matches any API routes then, It will look for it's route on the React App. If it doesn't any routes in the React app either then, The React app will simply show the 404 route.
2. Backend uses the Code-First database approach. So, Everytime you want to create a collection then, You have to add a JS file inside Models folder containing all the information about the collection.
3. react-frontend folder is attached to the application. It contains all the UI components of the application.
4. The app consists of two parts. Frontend & Backend, The Frontend is built on top of react and the backend is built on top of Express Framework on Nodejs with MongoDB as database.
5. The build file from react-frontend is saved in the web folder. Which is bounded with the main route of Express Server. So, When you hit the URL on the main server it will take you to the GigSmart main page.
6. MongoDB Connection String is saved in the .env file, You can see that in order to check the database.
7. Express framework doesn't support file upload by default. So, I've used a library express-fileupload to find a way around. I've used the upload() function from this library and bounded it with the app.use() middleware function from express server So, It supports form-data requests, Which makes it easier to upload files.
8. Generic Socket implementation. Which will make it easy to manage stuff.
Now, We don't have to create a socket on another port. We will simply intiliaze
the socket on same port as the application. From now on, We just need one socket
and it will take care of chats, notification and any other feature that requires
socket implementation.

Here are the rules to connect to the socket.
1. user is available in the socket object.
2. User ID is also registered on the socket.
3. You must pass JWT to connect to the socket otherwise your request will be declined.
4. For using it for notifications create a notification event and emit to this event from everywhere.
5. You can get the socket object using "app.get('socket');"
6. I'll use this socket for chat too. This will be a generalized socket which will work for  all type of actions.
7. It is available everywhere in the application.
