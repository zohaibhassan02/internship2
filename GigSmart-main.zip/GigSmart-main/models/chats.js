import mongoose from 'mongoose';

const  chatSchema = new mongoose.Schema({
    userid: {
        type: mongoose.SchemaTypes.ObjectId,
        required: [true, "User id is required"]
    },
    connectedWith: {
        type: mongoose.SchemaTypes.ObjectId,
        required: [true, "Connected with field is required!"]
    },
    created: {
        type: Date,
        default: () => Date.now()
    }
});
export default mongoose.model('chat', chatSchema);