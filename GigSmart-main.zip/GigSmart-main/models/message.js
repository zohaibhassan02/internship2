import mongoose from 'mongoose';

const  messageSchema = new mongoose.Schema({
    chatid: {
        type: mongoose.SchemaTypes.ObjectId,
        required: [true, "User id is required"]
    },
    userid: {
        type: mongoose.SchemaTypes.ObjectId,
        required: [true, "Userid is required!"]
    },
    type: {
        type: String,
        required: [true, "Message Type is required"]
    },
    message: {
        type: String,
        required: [true, "Message is required!"]
    },
    created: {
        type: Date,
        default: () => Date.now()
    }
});
export default mongoose.model('messages', messageSchema);