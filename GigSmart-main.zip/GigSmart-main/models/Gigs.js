import mongoose from 'mongoose';

const gigSchema = new mongoose.Schema({
    cover_image: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    introduction: {
        type: String,
        required: true
    },
    details: {
        type: String,
        required: true
    },
    pricing_detail: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    location: {
        type: String,
        required: true
    },
    userid: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true
    },
    appointments: [
        {
            buyerId: mongoose.SchemaTypes.ObjectId,
            created: {
                type: Date, 
                default: () => Date.now()
            }
        }
    ],
    appointments_request: [
        {
            buyerId: mongoose.SchemaTypes.ObjectId,
            created: {
                type: Date, 
                default: () => Date.now()
            }
        }
    ],
    completed_appointments: [
        {
            buyerId: mongoose.SchemaTypes.ObjectId,
            created: {
                type: Date, 
                default: () => Date.now()
            }
        }
    ],
    reviews: [
        {
            reviewTitle: String,
            reviewText: String,
            created: {
                type: Date, 
                default: () => Date.now()
            }
        }
    ],
    created: {
        type: Date,
        default: () => Date.now()
    }
});
export default mongoose.model('gigs',gigSchema);