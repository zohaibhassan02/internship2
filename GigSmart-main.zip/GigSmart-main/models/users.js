import mongoose from 'mongoose';

const usersSchema = new mongoose.Schema({
    username: {
        type: String,
        unique: true,
        required: [true, "Username is required"], 
    },
    password: {
        type: String,
        min: [8,"Password must be 8 characters"],
        required: true
    },
    email: {
        type: String,
        unique: true,
        required: [true, "Email is required"],
    },
    type: {
        type: String,
        required: [true, "User Type is required"]
    },
    provider_name: { // if user signs up from third party oAuth
        type: String
    },
    provider_id: { // if user signs up from third party oAuth
        type: String
    },
    fullName:{
        type: String
    },
    about:{
        type: String
    },
    profile_picture:{
        type: String
    },
    dob: {
        type: Date
    },
    city: {
        type: String
    },
    state: {
        type: String
    },
    country: {
        type: String
    },
    verificationToken: {
        type: String
    }
});
export default mongoose.model('users',usersSchema);