const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
    postid: {
        type: String,
        required: true
    },
    
    userid: {
        type: String,
        required: true
    },
    
    reply: {
        type: String,
        required: true
    },

    likes: {
        type: Array,
        default: []
    }
},
{ timestamps: true }

);

module.exports = mongoose.model('comment', CommentSchema);