const router = require('express').Router();
const controller = require('../controllers/postController');
const jwtMiddleware = require('../middleware/jwtMiddleware');


//Create post
router.post('/add',jwtMiddleware, controller.addPost);

//Update post
router.put('/:id/edit',jwtMiddleware, controller.editPost);

//delete post
router.delete('/:id/delete', jwtMiddleware, controller.delPost);

//Get single post
router.get('/:id', controller.getaPost);

//Get comments of posts
router.get('/:id/comments', controller.getCompost);

//Get all posts
router.get('/', controller.getPosts);

//Like post
router.patch('/:id/like', jwtMiddleware, controller.likePost);


module.exports = router;