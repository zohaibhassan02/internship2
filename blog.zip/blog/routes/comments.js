const router = require("express").Router();
const controller = require('../controllers/commentController');
const jwtMiddleware = require('../middleware/jwtMiddleware');


//Post Comment
router.post('/:id/add',jwtMiddleware, controller.addCom);

//Update comment
router.put('/:id/edit', jwtMiddleware, controller.editCom);

//Delete Comment
router.delete('/:id/delete', jwtMiddleware, controller.delCom);

//Get single comment
router.get('/:id', controller.getaCom);

//Get all comments
router.get('/', controller.getComs);

//Add Likes
router.patch('/:id/like', jwtMiddleware, controller.likeCom);


module.exports = router;
