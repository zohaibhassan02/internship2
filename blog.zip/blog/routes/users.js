const router = require('express').Router();
const controller = require('../controllers/userController');
const jwtMiddleware = require('../middleware/jwtMiddleware');


//Update
router.put('/edit',jwtMiddleware, controller.editUser);

//Delete
router.delete('/delete', jwtMiddleware, controller.delUser);

//Get single user
router.get('/:id', controller.getUser);

//Upload profilePic
router.post('/image/', jwtMiddleware, controller.addImage);


module.exports = router;