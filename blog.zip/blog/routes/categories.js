const router = require("express").Router();
const controller = require('../controllers/categoryController');
const jwtMiddleware = require('../middleware/jwtMiddleware');


//Posting Category
router.post('/add', jwtMiddleware, controller.addCategory);

//Get all Categories
router.get('/', controller.getCategory);

module.exports = router;