
const Comment = require("../models/Comment");
const Post = require('../models/Post');
const User = require('../models/User');


//Post Comment
addCom = async(req, res) => {
    //check if post id and username exist or not
    const com_post = await Post.findById({ _id: req.params.id })
    if(com_post){
            try{
                const newComment = new Comment({
                    postid: req.params.id,
                    userid: req.user._id,
                    reply: req.body.reply
                });
                const savedComment = await newComment.save();
                res.status(200).json(savedComment);
            }
            catch(err){
                res.status(500).json(err);
            }
    }
    else{
        res.status(401).json('No such post exists');
    }
};


//Update comment
editCom = async(req, res) => {
    try{
        const comment = await Comment.findById(req.params.id);
        if(comment.userid == req.user._id){
            try{
                const updatedComment = await Comment.findByIdAndUpdate(req.params.id, {
                    $set: {
                        reply: req.body.reply
                    }
                },{new:true});
                res.status(200).json(updatedComment);
            }
            catch(err){
                res.status(500).json(err);
            }
        }
        else{
            res.status(401).json("You can update only your comment");
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Delete Comment
delCom = async(req, res) => {
    //outer try is necessary or else app will crash if comment does not exist(comment.username = null)
    try{
        const comment = await Comment.findById(req.params.id);
        if(req.user._id == comment.userid){
            try{
                // await Post.findByIdAndDelete(req.params.id);
                // alternative method
                await comment.delete();
                res.status(200).json("Comment deleted...")
            }
            catch(err){
                res.status(500).json(err);
            }
        }
        else{
            res.status(401).json("You can delete only your comment");
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get single comment
getaCom = async(req, res) => {
    try{
        const comment = await Comment.findById(req.params.id);
        res.status(200).json(comment);
    }
    catch(err){
        res.status(500).json(err);
    }
};


//Get all comments
getComs = async(req, res) => {
    const user = req.query.user;
    const post = req.query.post;
    try{
        let comments;
        if(user){
            comments = await Comment.find({ userid: user });
        }
        else if(post){
            comments = await Comment.find({ postid: post });
            console.log(comments);
        }
        else{
            comments = await Comment.find();
        }
        res.status(200).json(comments);
    }
    catch(err){
        res.status(500).json(err);
    }
}

likeCom = async(req, res) => {
    try {
        const comment = await Comment.findById(req.params.id);
        if (!comment.likes.includes(req.user.username)) {
            await comment.updateOne({ $push: { likes: req.user.username } });
            res.status(200).json("The comment has been liked");
        } 
        else {
            await comment.updateOne({ $pull: { likes: req.user.username } });
            res.status(200).json("The comment has been disliked");
        }
    } 
    catch (err) {
        res.status(500).json(err);
    }
}

module.exports = {
    addCom,
    editCom,
    delCom,
    getaCom,
    getComs,
    likeCom
}
