
const User = require('../models/User');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');

//Update
editUser = async(req, res) => {
    if(req.body.password){
        const salt = await bcrypt.genSalt(10);
        newHashPassword = await bcrypt.hash(req.body.password, salt);
    
        try{
            const updatedUser = await User.findByIdAndUpdate(req.user._id, { $set: { password: newHashPassword }
            },{new:true});
            res.status(200).json(updatedUser);
        }
        catch(err){
            res.status(500).json(err);
        }
    }
    else{
        res.status(401).json("You can only update your password and nothing else");
    }
}


//Delete
delUser = async(req, res) => {
    try{
        await Comment.deleteMany({ username: req.user.username });
        await Post.deleteMany({ username: req.user.username });
        await User.findByIdAndDelete(req.user._id)
        res.status(200).json("User has been deleted...");
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get single user
getUser = async(req, res) => {
    try{
        const user = await User.findById(req.params.id);
        const { password, ...others } = user._doc;
        res.status(200).json(others);
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Upload profilePic
addImage = async(req, res, next) => {

    const storage = multer.diskStorage({
        destination: './upload/images',
        filename: (req, file, cb) => {
            return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
        }
    })

    const upload = multer({
        storage: storage,
        limits: { fileSize: 100000000 }
    }).single('profilePic');

    upload (req, res, async function (err){
        if(err){
            console.log(err);
        }
        else {
            await User.findByIdAndUpdate(req.user.id, { $set: { profilePic: `http://localhost:5000/image/${req.file.filename}` }})
            res.status(200).json("Profile picture succesfully added"); 
        }
    });

}



module.exports = {
    editUser,
    delUser,
    getUser,
    addImage
}