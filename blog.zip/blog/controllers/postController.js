
const User = require('../models/User');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const Category = require('../models/Category');


//Create post
addPost = async(req, res) => {
    try{
        console.log(req.user);
        const newPost = new Post({
            title: req.body.title,
            desc: req.body.desc,
            userid: req.user._id,
            categories: req.body.categories
        });
        const savedPost = await newPost.save();

        if(req.body.categories){

            //if post category does not exist
            const cat = await Category.findOne({ name: req.body.categories })
            if(!cat){
                const newCat = new Category({
                    name: req.body.categories
                });
                try{
                    const savedCat = await newCat.save();
                }
                catch(err){
                    res.status(500).json(err);
                }
            }
        }
        res.status(200).json(savedPost);
    }
    catch(err){
        res.status(500).json(err);
    }
}



//Update post
editPost = async(req, res) => {
    try{
        const post = await Post.findById(req.params.id);
        if(post.userid == req.user._id){
            try{
                const updatedPost = await Post.findByIdAndUpdate(req.params.id, {
                    $set: {
                        title: req.body.title,
                        desc: req.body.desc,
                        categories: req.body.categories
                    }
                },{new:true});
                res.status(200).json(updatedPost);
            }
            catch(err){
                res.status(500).json(err);
            }
        }
        else{
            res.status(401).json("You can update only your post");
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//delete post
delPost = async(req, res) => {
    try{
    //outer try is necessary or else app will crash after 2 deletes/ if post does not exist(post.username = null)
        const post = await Post.findById(req.params.id);
        if(req.user._id == post.userid){
            try{
                // await Post.findByIdAndDelete(req.params.id);
                // alternative method
                post.delete();
                res.status(200).json("Post deleted...")
            }
            catch(err){
                res.status(500).json(err);
            }
        }
        else{
            res.status(401).json("You can delete only your post");
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get single post
getaPost = async(req, res) => {
    try{
        const post = await Post.findById(req.params.id);
        res.status(200).json(post);
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get post commments
getCompost = async(req, res) => {
    try{
        const post = await Post.findById(req.params.id);
        if(post){
            try{
                const comments = await Comment.find({ postid: req.params.id })
                if(comments){
                    res.status(200).send({ POST: post, COMMENTS: comments});
                }
                else{
                    res.status(401).json("No comments with this post");
                }
            }
            catch(err){
                res.status(500).json(err);
            }
        }
        else{
            res.status(401).json("No such post exists");
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get all posts
getPosts = async(req, res) => {
    const username = req.query.user;
    const catname = req.query.cat;
    try{
        let posts;
        if(username){
            posts = await Post.find({ username: username });
        }
        else if(catname){
            posts = await Post.find({ 
                categories: {
                    $in: [catname],
                },
            });
            console.log(posts);
        }
        else{
            posts = await Post.find();
        }
        res.status(200).json(posts);
    }
    catch(err){
        res.status(500).json(err);
    }
}


likePost = async(req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post.likes.includes(req.user.username)) {
            await post.updateOne({ $push: { likes: req.user.username } });
            res.status(200).json("The post has been liked");
        } 
        else {
            await post.updateOne({ $pull: { likes: req.user.username } });
            res.status(200).json("The post has been disliked");
        }
    } 
    catch (err) {
        res.status(500).json(err);
    }
}


module.exports = {
    addPost,
    editPost,
    delPost,
    getaPost,
    getCompost,
    getPosts,
    likePost
}