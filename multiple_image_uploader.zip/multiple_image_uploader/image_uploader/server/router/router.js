const route = require('express').Router();
const imageController = require('../controller/imageController.js')
const store = require('../middleware/multer.js')
// routes
route.get('/', imageController.home);

route.post('/uploadmultiple', store.array('images', 5), imageController.uploads)
module.exports = route;