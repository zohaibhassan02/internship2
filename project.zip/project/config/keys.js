module.exports = {
    MongoURI: 'mongodb+srv://zohaib02:zohaib02@cluster0.dp9qw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}