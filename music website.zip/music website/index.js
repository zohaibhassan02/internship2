// let trackInput = document.getElementById('trackInput');
// let submitButton = document.getElementById('submitButton');
// var track;

// submitButton.onclick = searchTracks();

// function searchTracks(){
//     let searchResults = trackInput.value;
//     fetch('https://api.soundcloud.com/tracks/?client_id=wWZrDYsQemr1p5WldG0mp2zzuwhoSMG2' + searchResults).then(function(res){
//         if(res.status != 200){
//             console.log('Looks like there was a problem. Status Code: ' + res.status);
//             return;
//         }

//         res.json().then(function(data){
//             track = data;
//             console.log(data);
//         })
//     })
// }

// function renderTracks(){
//     return `${track.map(track =>
//         `<div class="box">
//         <div src="${track.stream_url}"></div>
//         <button id="albumBtn" class="albumButton">
//         <img id="${track.stream_url}${wWZrDYsQemr1p5WldG0mp2zzuwhoSMG2}" src="${track.artwork_url}"></img>
//         </button>
//         <div id="songTitle" class="title">${track.title}</div>
//         </div>`
//         )}
//         `
// }


// let markup = `${renderTracks()}`;
// document.getElementById('bands').innerHTML = markup;

// //wWZrDYsQemr1p5WldG0mp2zzuwhoSMG2

// const sckey = require('soundcloud-key-fetch');
// // sckey.fetchKey().then(key => {
// //     console.log(key)
// // });

// sckey.testKey('wWZrDYsQemr1p5WldG0mp2zzuwhoSMG2').then(res => {
//     if(res){
//         console.log("Key working");
//     }
//     else{
//         console.log("invalid");
//     }
// })

var express = require('express');
var request =  require('request');
var config = require('./config');
var app = module.exports = express();

//middleware
app.use(express.json());

var playlists = require('./routes/playlists');

//Routes
app.use('/playlists', playlists);

app.listen(config.port, function () {
  console.log('Soundcloud app listening on port:'+ config.port)
});