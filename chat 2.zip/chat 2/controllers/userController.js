const User = require('../models/User');
const jwt = require('jsonwebtoken');


//Register
register = async(req, res) => {
        try{
            const u = await User.findOne({ username: req.body.username });
            if(u){
                res.status(401).json("User already registered");
            }
            else{
                const newUser = new User({
                    username: req.body.username,
                    password: req.body.password
                });
                const user = await newUser.save();
                if(user){
                    const token = jwt.sign({userId: user._id}, "dnhaernhihjeiob", { expiresIn: '5d'});
                    res.status(200).json({user: user, token: token});
                }
                else{
                    res.status(401).json("Unable to register user");
                }
            }
        }
        catch(err){
            res.status(500).json(err);
        }
}

login = async(req, res) => {
    try{
        const user = await User.findOne({ username: req.body.username, password: req.body.password });
        if(!user){
            res.status(400).json("Wrong credentials");
        }
        else{
            // Generate JWT Token
            const token = jwt.sign({userId: user._id}, "dnhaernhihjeiob", { expiresIn: '5d'});

            // const { password, ...others } = user._doc;
            res.status(200).json({ user: user, token: token });
        }
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Update
editUser = async(req, res) => {
    if(req.body.password){
        try{
            const updatedUser = await User.findByIdAndUpdate(req.body._id, {password:req.body.password})
            res.status(200).json(updatedUser);
        }
        catch(err){
            res.status(500).json(err);
        }
    }
    else{
        res.status(401).json("You can only update your password and nothing else");
    }
}


//Delete
delUser = async(req, res) => {
    try{
        await User.findByIdAndDelete(req.body._id)
        res.status(200).json("User has been deleted...");
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get single user
getUser = async(req, res) => {
    try{
        const user = await User.findById(req.user._id);
        const { password, ...others } = user._doc;
        res.status(200).json(others);
    }
    catch(err){
        res.status(500).json(err);
    }
}


module.exports = {
    register,
    login,
    editUser,
    delUser,
    getUser
}