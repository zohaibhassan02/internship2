const Room = require('../models/Room');


//Register
addRoom = async(req, res) => {
    if(req.body === undefined || req.body === ''){
        res.status(500).json("Error no body");
    }
    else{
        var users = JSON.parse(req.body.users);
        users.push(req.user.username);

        const roomExists = await Room.findOne({ name: req.body.name, admin: req.user.username},{ users: users});
        if(!roomExists){

            const newRoom = new Room({
                name: req.body.name,
                admin: req.user.username,
                users: users
            });

            try {
                const savedRoom = await newRoom.save();
                res.status(200).json(savedRoom);
            } catch (err) {
                res.status(500).json(err);
            }
        }
        else{
            res.status(400).json({ error: "room already exists", room: roomExists});
        }
    }
}

//Get all room names
getRooms = async(req, res) => {
   try{
       const room = await Room.find()
       if(room){
           res.status(200).json(room);
       }
       else{
           res.status(401).json("No room exist");
       }
    }
    catch(err){
       res.status(500).json(err);
    }
}


// //Get all convos between 2 users
// getConvoTwo = async(req, res) => {
//     try{
//         const room = await room.findOne({
//             members: { $all: [req.params.firstUserId, req.params.secondUserId] },
//         });
//         res.status(200).json(room)
//     }
//     catch(err){
//         res.status(500).json(err);
//     }
// }


// //Get all convos of a user
// getConvoOne = async(req, res) => {
//     try{
//         const room = await room.find({
//             members: { $in: [req.params.userId] },
//         });
//         res.status(200).json(room);
//     }
//     catch(err){
//         res.status(500).json(err);
//     }
// }


module.exports = {
    addRoom,
    getRooms
}