const router = require('express').Router();
const controller = require('../controllers/userController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

//Register
router.post('/register', controller.register);

//Login
router.post('/login', controller.login);

//Update
router.put('/edit', jwtMiddleware, controller.editUser);

//Delete
router.delete('/delete', jwtMiddleware, controller.delUser);

//Get single user
router.get('/', jwtMiddleware, controller.getUser);


module.exports = router;