const router = require('express').Router();
const controller = require('../controllers/roomController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

//Register
router.post('/add', jwtMiddleware, controller.addRoom);

//Get all rooms
router.get('/', jwtMiddleware, controller.getRooms);


module.exports = router;