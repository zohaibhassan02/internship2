const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');
const userRoute = require('./routes/users');
const roomRoute = require('./routes/rooms.js');
const app = express();
const http = require('http');
const server = http.createServer(app);
const socketio = require('socket.io');
const io = socketio(server);
const formatMessage = require('./utils/messages');
const { userJoin, getCurrentUser, userLeave, getRoomUsers, getUserSocket } = require('./utils/users');
const User = require('./models/User');
const Room = require('./models/Room');
const Message = require('./models/Message');
const siofu = require('socketio-file-upload');

// For body parsing of json 
app.use(express.json());

app.use(express.static(__dirname + '/uploads'));

mongoose.connect("mongodb://localhost:27017/chat", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(console.log("Database connected"))
  .catch((err) => console.log(err));

app.use(cors());

// app.use(siofu.router());

app.use('/api/users', userRoute);
app.use('/api/rooms', roomRoute);


const botname = 'MaceBot';

io.on('connection', (socket) => {
    
    socket.on('joinRoom', async({ username, room }) => {
        const u = await User.findOne({ username: username});
        const r = await Room.findOne({ name: room, users: { $elemMatch: { $eq: u.username}}});

        if(u && r){
            const user = userJoin(socket.id, username, room);

            socket.join(user.room);

            socket.emit('message', formatMessage(botname, 'Welcome to Macebook'));
            
            // Broadcast when a user connects
            socket.broadcast.to(user.room).emit('message', formatMessage(botname, `${user.username} has joined the chat`));
        
            // send usernames of ppl online in room
            io.to(user.room).emit('roomUsers', {
                room:user.room,
                users: getRoomUsers(user.room)
            });

            socket.on('chat', async (req)  => {
        
                const user = getCurrentUser(socket.id);
                // msg = JSON.stringify(req.);
                var users_online = getRoomUsers(user.room);

                console.log(users_online);
                for(i=0; i<users_online.length; i++){
                    if(users_online[i].username === user.username){
                        continue;
                    }
                

                    var readBy = []
                    readBy.push(users_online[i].username);
                }

                console.log(readBy);

    
                const newMessage = new Message({
                    room: user.room,
                    sender: user.username,
                    text: req.msg,
                    readBy: readBy
                });
    
                savedMessage = await newMessage.save();
                if(savedMessage){
                    io.to(user.room).emit('chat', formatMessage(user.username, req.msg))
                }
                else{
                    socket.emit('err', formatMessage(botname, 'Could not save message to database'));
                }
            });

        
            socket.on('add', async(req) => {
                const user = await getCurrentUser(socket.id);
                if(req.username){
                    if(r.admin === user.username){
                        await r.updateOne({ $push: { users: req.username }});
                        io.to(user.room).emit('message', formatMessage(botname, `${req.username} has been added`));
                    }
                    else{
                        socket.emit('err', formatMessage(botname, "You need admin rights to perform this function"));
                    }
                }
                else{
                    socket.emit("err", formatMessage(botname, "No username provided"));
                }
            });

            socket.on('remove', async(req) => {
                const user = getCurrentUser(socket.id);
                if(r.admin === user.username){
                    const kicked_user = await getUserSocket(req.username)

                    if(kicked_user){

                        io.sockets.sockets.forEach((socket) => {
                            // If given socket id is exist in list of all sockets, kill it
                            if(socket.id === kicked_user.id)
                                socket.disconnect(true);
                        });
                    }
                    await r.updateOne({ $pull: { users: req.username }});
                
                    io.to(user.room).emit('message', formatMessage(botname, `${req.username} has been removed`));
                    socket.to(kicked_user).emit('message', formatMessage(botname, "You have been kicked from the group"));
                }
                else{
                    socket.to(user.room).emit('err', formatMessage(botname, "You need admin rights to perform this function"));
                }
            })

        // socket.on('upload', function (socket){
        //     var uploader = new siofu();
        //     uploader.dir = "uploads";
        //     uploader.listen(socket);
        // });

        // // Do something when a file is saved:
        // uploader.on("saved", function (event) {
        //     event.file.clientDetail.name = event.file.name; 
        // });

        // // Error handler:
        // uploader.on("error", function (event) {
        // console.log("Error from uploader", event);
        // });

            socket.on('disconnect', () => {
                const user = userLeave(socket.id);
        
                console.log('user disconnected');
                

                io.to(user.room).emit('message', formatMessage(botname, `${user.username} has left the chat`));

                // send usernames of ppl online in room
                socket.broadcast.to(user.room).emit('roomUsers', {
                    room:user.room,
                    users: getRoomUsers(user.room)
                });
            });

       
        }
        else{
            socket.emit('err', formatMessage(botname, 'No such username or room exists'));
        }

    });

});

server.listen(3000, () => {
    console.log('listening on *:3000');
});