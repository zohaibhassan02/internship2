import { Outlet } from "react-router-dom";
import { useState } from "react";

const Layout = () => {
        const [color, setColor] = useState("__");
      
        return (
    <>
      {/* <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/blogs">Blogs</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </nav> */}

      <h1>My favorite color is {color}!</h1>

      <button
        type="button"
        onClick={() => setColor("blue")}
      >Blue</button>

      <Outlet />
    </>
    )
};

export default Layout;