const express = require('express');
const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');

// Body parsing
app.use(express.json());

// DB connection
mongoose.connect('mongodb://localhost:27017/crud', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Mongodb connected......');
}).catch((error) => {
    console.log(error);
});

// app.get('/', (req, res) =>{
//     res.send('Hello World');
// });

// app.get('/employees', (req, res) => {
//     res.send('Employees');
// });

app.use('/api', require('./routes/index.js'));

app.listen(3000);