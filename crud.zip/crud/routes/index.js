const express = require('express');
const router = express.Router();

const { Employee } = require('../models/Employee.js');

// Get all employees
router.get('/employees', (req, res) => {
    Employee.find({}, (err, data) => {
        if(!err){
            res.send(data);
        }
        else{
            console.log(err);
        }
    });
});

// Save Employee
router.post('/employee/add', (req, res) => {
    const emp = new Employee({
        name: req.body.name,
        email: req.body.email,
        salary: req.body.salary
    });
    emp.save((err, data) => {
        res.status(200).json({ code:200, message: 'Employee added Successfully', addedEmployee: data});
    });
})


// Get single employee
router.get('/employee/:id', (req, res) => {
    Employee.findById(req.params.id, (err, data) => {
        if(!err){
            res.send(data);
        }
        else{
            console.log(err);
        }
    });
});

// Updating employee
router.put('/employee/edit/:id', (req, res) => {
    const emp = {
        name: req.body.name,
        email: req.body.email,
        salary: req.body.salary
    }
    Employee.findByIdAndUpdate(req.params.id, { $set: emp }, { new: true }, (err, data) => {
        if(!err){
            res.status(200).json({ code:200, message: 'Employee Updated', updatedEmployee: data});
        }
        else{
            console.log(err);
        }
    });
});

// Delete employee
router.delete('/employee/delete/:id', (req, res) => {
    Employee.findByIdAndDelete(req.params.id, (err, data) => {
        if(!err){
            res.status(200).json({ code: 200, message: "Employee successfully deleted", deleteEmployee: data});
        }
        else{
            console.log(err);
        }
    });
});

module.exports = router;