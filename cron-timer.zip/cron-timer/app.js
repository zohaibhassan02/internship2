import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import connectDb from './config/db.js';
import userRoutes from './routes/userRoutes.js';
import UserModel from './models/User.js'
import * as cron from 'node-cron';
import transporter from "./config/email.js";

dotenv.config();

const app = express();
const port = process.env.PORT ;
const DATABASE_URL = process.env.DATABASE_URL;

// CORS Policy
app.use(cors());

// Database Connection
connectDb(DATABASE_URL);

// JSON
app.use(express.json());

// Load Routes
app.use('/api/user', userRoutes);

// Image
app.use('/profile', express.static('upload/images'));


cron.schedule('*/1 * * * *', async () => {

    const users = await UserModel.find({ tc: false });

    if(users){

        for (let user of users) {

            var link = `http://127.0.0.1:8000/api/user/verify/${user._id}`

            let code = Math.floor(1000 + Math.random() * 9000);

            const data = await UserModel.findByIdAndUpdate(user._id, { email_token: code });

            await transporter.sendMail({
                from: process.env.EMAIL_FROM,
                to: user.email,
                subject: "Email Verification",
                html: `<a href=${link}>Click here </a> to Confirm your email address. Your code is ${code}`
            });
            console.log("email sent");
        }
    }
    
});

app.listen(port, () => {
    console.log(`Server listening at port ${port}`);
});