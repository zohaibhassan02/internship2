import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import mongoose from "mongoose";
import upload from 'express-fileupload';
import path from 'node:path';
import { MongoUtil } from './helpers/mongoUtils.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import chat from "./websockets/chat.js";
import users from "./routes/users.js";
import playlist from "./routes/playlist.js";
import roomRoute from "./routes/room.js";
import room from "./websockets/room.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

var PORT = process.env.PORT;
var DB_URL = process.env.DB_URL;

const app = express();
app.use(cors());
app.use(express.json());
app.use(upload());
app.use(express.static("public"));

app.use("/api/users", users);

app.use("/api/playlist", playlist);

app.use("/api/room", roomRoute);

chat.initChat();

room.initRoom();

mongoose.connect(DB_URL, (err, db) => {
    if (err) console.error(err);
    let dbo = db.client.db('nightdistrict');
    MongoUtil.getInstance(dbo);
    console.log('Database Connected!');
});

//mongoose.connect(DB_URL, (e) => console.log(e == null ? "Database Connected!" :e));
app.use(express.static(path.join(__dirname, 'web')));
app.get('/*', function (req, res) {
    res.sendFile(path.join(__dirname, 'web', 'index.html'));
});
app.listen(PORT, () => console.log(`Server running on port: http://localhost:${PORT}`));