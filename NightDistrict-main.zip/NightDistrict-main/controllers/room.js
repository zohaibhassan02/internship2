import Room from '../models/room.js';


//Register
const addRoom = async(req, res) => {
    const newRoom = new Room({
        djId: req.body.id,
        roomName: req.body.roomName,
        password: req.body.password
    });
    
    try {
        const savedRoom = await newRoom.save();
        res.status(200).json(savedRoom);
    } catch (err) {
        res.status(500).json(err);
    }
}

//Get all room names
const getRooms = async(req, res) => {
   try{
       const room = await Room.find()
       if(room){
           res.status(200).json(room);
       }
       else{
           res.status(401).json("No room exist");
       }
    }
    catch(err){
       res.status(500).json(err);
    }
}


export default {
    addRoom,
    getRooms
}