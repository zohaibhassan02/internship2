import express from "express";
const router = express.Router();
import spotify from "../controllers/spotify.js"
import list from "../controllers/list.js"
import tokenValidation from "../validation/tokenValidation.js";
    
router.get('/login', spotify.login);
    
router.get('/callback', spotify.callback);

router.post('/set', spotify.set);

router.get('/refresh_token', tokenValidation, spotify.refresh_token);

router.get('/', tokenValidation, list.getPlaylists);

router.get('/:playlistId', tokenValidation, list.getTracks);

export default router;