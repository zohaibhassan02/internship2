import express from 'express';
const router = express.Router();
import controller from '../controllers/room.js';

//Register
router.post('/', controller.addRoom);

//Get all rooms
router.get('/', controller.getRooms);


export default router;