import User from '../models/users.js';
import Socket from 'socket.io';
import Track from '../models/track.js';
import Room from '../models/room.js';
import { userJoin, getCurrentUser, userLeave, getRoomUsers } from '../helpers/roomusers.js';
import { formatMessage } from '../helpers/messages.js';


function initRoom() {
    const io = new Socket(5555, {
        cors: {
            origin: '*'
        }
    });

    let celebrate = [];
    let cheers = [];

    const botname = 'NightDistrict Bot';

    io.on('connection', (socket) => {
        console.log("user connected");
        socket.emit('message', formatMessage(botname, 'Welcome to Night District'));

        socket.on('joinRoom', async({ email, roomName, password }) => {
            try{
                const u = await User.findOne({ email: email })
                const r = await Room.findOne({ roomName: roomName, password: password});
                if(r && u){
                    const user = userJoin(socket.id, email, roomName);

                    socket.join(user.roomName);

                    socket.emit('message', formatMessage(botname, `Welcome to ${user.roomName}`));

                    // Broadcast when a user connects
                    socket.broadcast.to(user.roomName).emit('message', formatMessage(botname, `${user.email} has joined the chat`));

                    // send emails of ppl online in room
                    io.to(user.roomName).emit('roomUsers', {
                        roomName:user.roomName,
                        users: getRoomUsers(user.roomName)
                    });
                    
                }
                else{
                    socket.emit('err', formatMessage(botname, 'No such email or room exists'));
                }
            }
            catch(err){
                socket.emit('err', formatMessage(botname, err));
            }
        });


        socket.on('comment', async (msg)  => {
            const user = getCurrentUser(socket.id);
            io.to(user.roomName).emit('comment', formatMessage(user.email, msg));
        });


        socket.on('cheers', () => {
            const user = getCurrentUser(socket.id);
            const index = cheers.indexOf(user.email);
            if (index > -1) {
                cheers = cheers.filter(function(item) {
                    return item !== user.email 
                })
                
                var count = cheers.length;
                io.to(user.roomName).emit('cheersCount', `The count is ${count}`);
            }
            else{
                cheers.push(user.email);
                var count = cheers.length;
                io.to(user.roomName).emit('cheersCount',`The count is ${count}`);
            }
        });

        socket.on('celebrate', () => {
            const user = getCurrentUser(socket.id);
            const index = celebrate.indexOf(user.email);
            if (index > -1) {
                celebrate = celebrate.filter(function(item) {
                    return item !== user.email 
                })
                
                var count = celebrate.length;
                io.to(user.roomName).emit('celebrateCount', `The count is ${count}`);
            }
            else{
                celebrate.push(user.email);
                var count = celebrate.length;
                io.to(user.roomName).emit('celebrateCount',`The count is ${count}`);
            }
        });

        socket.on('voted', async ({ spotifytrackId }) => {
            const user = getCurrentUser(socket.id);

            const [track] = await Track.find({ "tracksInfo.spotifytrackId": spotifytrackId }, {_id:0, tracksInfo: { $elemMatch: {spotifytrackId: spotifytrackId }}}, {"tracksInfo.$": 1});
    
            for(let i=0; i < track.tracksInfo.length; i++){

                const index = track.tracksInfo[i].voted.indexOf(user.email);
                if (index > -1) {
                    await Track.updateMany({ 'tracksInfo': { $elemMatch : { spotifytrackId: spotifytrackId }}}, {$pull: {"tracksInfo.$.voted" : user.email }}, { 'multi': true })
                }
                else{
                    await Track.updateMany({ 'tracksInfo': { $elemMatch : { spotifytrackId: spotifytrackId }}}, {$push: {"tracksInfo.$.voted" : user.email }}, { 'multi': true })
                }
            }
        })

        socket.on('downvoted', async ({ spotifytrackId }) => {
            const user = getCurrentUser(socket.id);

            const [track] = await Track.find({ "tracksInfo.spotifytrackId": spotifytrackId }, {_id:0, tracksInfo: { $elemMatch: {spotifytrackId: spotifytrackId }}}, {"tracksInfo.$": 1});
    
            for(let i=0; i < track.tracksInfo.length; i++){

                const index = track.tracksInfo[i].downvoted.indexOf(user.email);
                if (index > -1) {
                    await Track.updateMany({ 'tracksInfo': { $elemMatch : { spotifytrackId: spotifytrackId }}}, {$pull: {"tracksInfo.$.downvoted" : user.email }}, { 'multi': true })
                }
                else{
                    await Track.updateMany({ 'tracksInfo': { $elemMatch : { spotifytrackId: spotifytrackId }}}, {$push: {"tracksInfo.$.downvoted" : user.email }}, { 'multi': true })
                }
            }
        })

        socket.on('disconnect', () => {
            const user = userLeave(socket.id);
            if(user){
                io.to(user.roomName).emit('message', formatMessage(botname, `${user.email} has left the chat`));

                // send email of ppl online in room
                socket.broadcast.to(user.roomName).emit('roomUsers', {
                    roomName:user.roomName,
                    users: getRoomUsers(user.roomName)
                });
            }
        });
    });
}

export default { initRoom };