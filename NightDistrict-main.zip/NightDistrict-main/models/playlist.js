import mongoose from "mongoose";
const playlistSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    playlistsInfo: [{
        spotifyplaylistId: {
            type: String
        },
        name: { 
            type: String 
        }
    }]
});
export default mongoose.model("playlist", playlistSchema)