import mongoose from "mongoose"
const customersSchema = mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    latitude: {
        type: Number
    },
    longitude: {
        type: Number
    },
    otpCode: {
        type: String
    },
    jwtToken: {
        type: String
    },
    access_token:{
        type: String
    },
    refresh_token:{
        type: String
    },
    fcmToken: {
        type: String
    },
    phoneNo: {
        type: String,
        default: ''
    },
    profilePic: {
        type: String,
        default: ''
    },
    chatFriends: {
        type: Array
    },
    giftCard: [
        {
            giftCardId: mongoose.Schema.Types.ObjectId,
            paymentId: String,
            remaining: Number,
            expireAt: Date
        }
    ],
    onlineStatus: {
        type: String
    },
    status: {
        type: Number,
        default: 1
    },
});
export default mongoose.model('customers', customersSchema);