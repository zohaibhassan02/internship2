import mongoose from "mongoose"

const RoomSchema = new mongoose.Schema({
    djId: {
        type: String,
        required: true
    },
    roomName: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
},
{ timestamps: true }

);

export default mongoose.model('rooms', RoomSchema);