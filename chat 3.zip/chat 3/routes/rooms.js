const router = require('express').Router();
const controller = require('../controllers/roomController');

//Register
router.post('/add', controller.addRoom);

//Get all rooms
router.get('/', controller.getRooms);


module.exports = router;