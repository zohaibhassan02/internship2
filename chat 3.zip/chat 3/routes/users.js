const router = require('express').Router();
const controller = require('../controllers/userController');

//Register
router.post('/register', controller.register);

//Update
router.put('/edit', controller.editUser);

//Delete
router.delete('/delete', controller.delUser);

//Get single user
router.get('/:id', controller.getUser);


module.exports = router;