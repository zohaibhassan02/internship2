const User = require('../models/User');


//Register
register = async(req, res) => {
        try{
            const u = await User.findOne({ username: req.body.username });
            if(u){
                res.status(401).json("User already registered");
            }
            else{
                const newUser = new User({
                    username: req.body.username,
                    password: req.body.password
                });
                const user = await newUser.save();
                if(user){
                    res.status(200).json(user);
                }
                else{
                    res.status(401).json("Unable to register user");
                }
            }
        }
        catch(err){
            res.status(500).json(err);
        }
}

//Update
editUser = async(req, res) => {
    if(req.body.password){
        try{
            const updatedUser = await User.findByIdAndUpdate(req.body._id, {password:req.body.password})
            res.status(200).json(updatedUser);
        }
        catch(err){
            res.status(500).json(err);
        }
    }
    else{
        res.status(401).json("You can only update your password and nothing else");
    }
}


//Delete
delUser = async(req, res) => {
    try{
        await User.findByIdAndDelete(req.body._id)
        res.status(200).json("User has been deleted...");
    }
    catch(err){
        res.status(500).json(err);
    }
}


//Get single user
getUser = async(req, res) => {
    try{
        const user = await User.findById(req.params.id);
        const { password, ...others } = user._doc;
        res.status(200).json(others);
    }
    catch(err){
        res.status(500).json(err);
    }
}


module.exports = {
    register,
    editUser,
    delUser,
    getUser
}