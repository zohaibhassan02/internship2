const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');
const userRoute = require('./routes/users');
const roomRoute = require('./routes/rooms.js');
const app = express();
const http = require('http');
const server = http.createServer(app);
const socketio = require('socket.io');
const io = socketio(server);
const formatMessage = require('./utils/messages');
const { userJoin, getCurrentUser, userLeave, getRoomUsers } = require('./utils/users');
const User = require('./models/User');
const Room = require('./models/Room');
const Message = require('./models/Message');

// For body parsing of json 
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/chat", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(console.log("Database connected"))
  .catch((err) => console.log(err));

app.use(cors());

app.use('/api/users', userRoute);
app.use('/api/rooms', roomRoute);


const botname = 'MaceBot';

io.on('connection', (socket) => {
    
    socket.on('joinRoom', async({ username, room }) => {
        const u = await User.findOne({ username: username});
        const r = await Room.findOne({ name: room});
        if(u && r){
            const user = userJoin(socket.id, username, room);

            socket.join(user.room);

            socket.emit('message', formatMessage(botname, 'Welcome to Macebook'));
            
            // Broadcast when a user connects
            socket.broadcast.to(user.room).emit('message', formatMessage(botname, `${user.username} has joined the chat`));
        
            // send usernames of ppl online in room
            io.to(user.room).emit('roomUsers', {
                room:user.room,
                users: getRoomUsers(user.room)
            });
       
        }
        else{
            socket.emit('error', formatMessage(botname, 'No such username or room exists'));
        }

    });
        
    socket.on('chat message', async (msg)  => {
            const user = getCurrentUser(socket.id);
            msg2 = JSON.stringify(msg);

            const newMessage = new Message({
                room: user.room,
                sender: user.username,
                text: msg2
            });

            savedMessage = await newMessage.save();
            if(savedMessage){
                io.to(user.room).emit('chat message', formatMessage(user.username, msg));
            }
            else{
                socket.emit('error', formatMessage(botname, 'Could not save message to database'));
            }

    });

    socket.on('disconnect', () => {
        const user = userLeave(socket.id);

            console.log('user disconnected');
            io.to(user.room).emit('message', formatMessage(botname, `${user.username} has left the chat`));

            // send usernames of ppl online in room
            socket.broadcast.to(user.room).emit('roomUsers', {
                room:user.room,
                users: getRoomUsers(user.room)
            });
    });

});

server.listen(3000, () => {
    console.log('listening on *:3000');
});