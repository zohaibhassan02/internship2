import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import cors from 'cors';
import connectDb from './config/db.js';
import userRoutes from './routes/userRoutes.js'; 

const app = express();
const port = process.env.PORT ;
const DATABASE_URL = process.env.DATABASE_URL;

// CORS Policy
app.use(cors());

// Database Connection
connectDb(DATABASE_URL)

// JSON
app.use(express.json());

// Load Routes
app.use('/api/user', userRoutes);

// Image
app.use('/profile', express.static('upload/images'));

app.listen(port, () => {
    console.log(`Server listening at port ${port}`);
});