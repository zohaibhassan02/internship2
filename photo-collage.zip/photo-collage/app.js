const express = require('express');
const app = express();
const fs = require('fs');
const cors = require('cors');

const createCollage = require('nf-photo-collage');

const multer = require('multer');
const path = require('path');

app.use(express.json());

// app.use(express.urlencoded());

app.use(express.static('./upload/images'));
// app.use(cors());

// app.get('/', (req, res) => {
//     res.sendFile(__dirname + "/index.html");
// })

// Storage engine (alternative to read in binary and write in png or jpeg format)


app.post('/photo', (req, res) => {

    const storage = multer.diskStorage({
        destination: './upload/images',
        filename: (req, file, cb) => {
            return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
        }
    })

    const upload = multer({
        storage: storage,
        limits: { fileSize: 100000000 }
    }).array('multi');

    upload (req, res, function (err){
        if(err){
            console.log(err);
        }
        else {
            // console.log(req.files);
            console.log(req.body);
            // await UserModel.findByIdAndUpdate(req.user._id, { $set: { profile: `http://localhost:3000/profile/${req.file.filename}` }})
            // res.status(401).send({ "status": "success", "message": "Profile added successfully" });
            var arr = [];
            for(let data of req.files){
                arr.push(
                    './upload/images/' + data.filename
                )
            }
                const options = {
                    sources: arr, 
                    width: parseInt(req.body.width), // number of images per row
                    height: parseInt(req.body.height), // number of images per column
                    imageWidth: parseInt(req.body.imageWidth), // width of each image
                    imageHeight: parseInt(req.body.imageHeight), // height of each image
                    // backgroundColor: "#cccccc", // optional, defaults to #eeeeee.
                    // backgroundImage: "./localfile.png" // same formats supported as source
                    spacing: parseInt(req.body.spacing), // optional: pixels between each image
                }
                console.log(options);
            createCollage(options)

            .then((canvas) => {
                const dest = fs.createWriteStream(__dirname + "/upload/collages/" + Date.now() + '.png');

                const src = canvas.pngStream();
                src.pipe(dest);

                src.pipe(res);

                // dest.on('finish', () => 
                // console.log("hellloooooo"));

                // res.status(200).send({ "status": "success", "message": "Profile added successfully" });
            })
            .catch((err) => {
                console.log(err)
            })
        }
    })
})

app.get('/', (req, res) => {
    res.sendFile(__dirname + "/index.html");
})

app.listen(3000, () => {
    console.log('Server running');
});